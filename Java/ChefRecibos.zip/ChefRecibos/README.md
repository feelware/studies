# Gran-Chef: recibos
La empresa Gran-Chef maneja diferentes tipos de recibos con los datos del emisor, la fecha y un
monto:

- En las Facturas se debe calcular el 19% IGV
- En las Boletas no se considera IGV
- En los Recibos de Honorarios se debe calcular un impuesto a la renta de 10%

Se pide almacenar todos los recibos de la empresa y calcular:
- Monto total Neto
- Monto total de impuestos
- Monto Total Bruto

# Uso
En la carpeta raiz del proyecto (ChefRecibos) ejecutar:
```bash
java com.App
```

# Créditos
- Jesus Stevan Diaz Ingol
- Renzo Jeanpier Santos Lozano

**Docente:** Jorge Luiz Chávez Soto
> EPISW, UNMSM. 2023